import pandas as pd
import re, string
from bs4 import BeautifulSoup
import nltk
from nltk import word_tokenize, sent_tokenize
import datetime
import time
import boto3
import pyodbc
from io import StringIO


aws_s3=boto3.resource('s3', aws_access_key_id='~~~~', aws_secret_access_key='~~~~~')
# Create a client
client = boto3.client('s3', region_name='us-east-2',aws_access_key_id='~~~', aws_secret_access_key='~~~')

# Create a reusable Paginator
paginator = client.get_paginator('list_objects')

# Create a PageIterator from the Paginator
page_iterator = paginator.paginate(Bucket='~~~')

#Extract Keys of the files
json_files = []
for page in page_iterator:
    if "Contents" in page:
        for key in page[ "Contents" ]:
            keyString = key[ "Key" ]
            if "HF" in keyString:
                if "2020-04-03" in keyString:#"03-06-2020"
                    if ".csv" in keyString:
                        json_files.append(keyString)
print(json_files)

for u in range (0,len(json_files)):
    csv_obj = client.get_object(Bucket='~~~~', Key=json_files[u])
    body = csv_obj['Body']
    csv_string = body.read().decode('utf-8')

    df = pd.read_csv(StringIO(csv_string))
    print ('File',json_files[u])
    print(len(df.columns))
    print(df[:10])