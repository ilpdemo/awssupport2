import pyodbc
import pandas as pd

cnxn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};'
                      'Server=***;'
                      'Database=***;'
                      'uid=***;'
                      'pwd=***;')

sql = 'SELECT * FROM [**].[dbo].[**]'
df = pd.read_sql(sql,cnxn)
print(df[:100])